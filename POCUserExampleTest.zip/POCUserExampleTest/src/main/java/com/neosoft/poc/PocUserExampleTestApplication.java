package com.neosoft.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocUserExampleTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocUserExampleTestApplication.class, args);
	}

}
